<div class="column third sidebar">
	<div>
		<img src="<?php echo get_template_directory_uri(); ?>/images/women_child.png">
		<h2>Get started on the path to healing!<i class="fa fa-angle-double-down"></i></h2>
		<form>
			<input type="text" placeholder="Name" required>
			<input type="email" placeholder="Email" required>
			<textarea placeholder="Enter a message"></textarea>
			<button>Submit <i class="fa fa-angle-double-right"></i></button>
		</form>
	</div>
</div>